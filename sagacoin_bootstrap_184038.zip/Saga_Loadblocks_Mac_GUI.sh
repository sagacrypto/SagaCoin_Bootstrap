./SagaCoin-Qt.app/Contents/MacOS/SagaCoin-Qt -loadblock=blk0001.dat
