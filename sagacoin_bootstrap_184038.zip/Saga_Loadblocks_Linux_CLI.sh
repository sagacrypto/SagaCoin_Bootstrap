./sagacoind -loadblock=blk0001.dat
