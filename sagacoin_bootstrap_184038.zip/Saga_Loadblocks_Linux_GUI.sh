./SagaCoin-qt -loadblock=blk0001.dat
